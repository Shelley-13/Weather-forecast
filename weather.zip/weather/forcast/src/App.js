import './App.css';
import {useState} from 'react';
import {ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip} from "recharts";


function App() {
  const api=[{},{city:"Delhi",temp:"53",humidity:"60%",windspeed:"8km/hr",desc:"Very hot in Delhi"},
    {city:"Mumbai",temp:"22",humidity:"90%",windspeed:"3km/hr",desc:"Humidity in Mumbai"},
    {city:"Lucknow",temp:"35",humidity:"70%",windspeed:"5km/hr",desc:"Sunny weather in lucknow"},
    {city:"Pune",temp:"27",humidity:"80%",windspeed:"4km/hr",desc:"Pune is Cloudy"},
    {city:"Hydrabad",temp:"31",humidity:"40%",windspeed:"9km/hr",desc:"Windy in Hydrabad"}
  ];
  // const [api,setApi]=useState([]);
  const [cit,setCit]=useState();
  const [newArr,setNewarr]=useState([]);

  // useEffect(()=>{
  //   fetch("http://api.weatherapi.com/v1/current.json?key=ca841f15c14543ec98a191501242806&q=London&aqi=no")
  //   .then((res)=>res.json())
  //   .then((data)=>setApi(data))
  // },[])
  const submitting=()=>{
    const res=api.filter((ele)=>ele.city===cit)
    setNewarr(res);
  }

  return (
    <>
    <div className="App">
      <h1 className="item-1">Search for City </h1><br/>
      <span className="item-2">
      <select defaultValue="" type="text" value={cit} onChange={(e)=>{setCit(e.target.value)}}>
      {
        api.map((elem,index)=>{return (<option key={index}>{elem.city}</option>)})
      }
      </select>
      </span>
      <span className="item-3"><button type="Submit" onClick={submitting}>SUBMIT</button></span>
      <ul className="lists">
      {
        newArr.map((elem,index)=>{return <li key={index}>Temprature: {elem.temp}🌡️, Humidity: {elem.humidity}💧, Windspeed: {elem.windspeed}🍃, Description: {elem.desc}📖</li>})
      }
      </ul>
      {newArr.length!==0 && <div className="charts"><ResponsiveContainer width="100%" aspect={1}>
        <BarChart data={api} width={500} height={500}>
          <XAxis dataKey="city"/>
          <YAxis/>
          <Tooltip/>
          <Bar dataKey="temp" fill="red"/>
        </BarChart>
      </ResponsiveContainer></div>}
      </div>
    </>
  );
}

export default App;